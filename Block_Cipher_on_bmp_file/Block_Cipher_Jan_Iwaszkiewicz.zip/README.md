Użyto funkcji skrótu SHA384.
W folderze jest dodatkowa bitmapa spełniająca warunki
zarówno zadania jak i programu.